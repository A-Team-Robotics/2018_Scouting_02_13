<?php include('includes/database.php'); ?>
<?php
	//Create the select query
	$query ="SELECT DISTINCT
	     teamNumber
			 FROM team_info
			 ORDER BY id DESC
			 ";
			
	//Get results
	$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
?>
<?php
?>
<?php
	if($_POST){
		//Get variables from post array
		$total = 0;
		$teamNumber = ($_POST['selectTeam']); //This value is used in both databases.
		$size = ($_POST['size']); //This value is used in both databases.
		$speed = explode ("|", $_POST['speed']); //Separates both values into an array.
		$rspeed = $speed[0]; //The first array value is the text, and it goes to the "robot_info" table.
		$pspeed = $speed[1]; //The second array value is the score, and it goes to the "team_points" table.
		$total += $pspeed;
		$strength = explode ("|", $_POST['strength']);
		$rstrength = $strength[0];
		$pstrength = $strength[1];
		$total += $pstrength;
        $strategy = ($_POST['strategy']); //This value is used in both databases.
		$numCubes = ($_POST['numCubes']); //This value is used in both databases, however the value in the "team_points" database will be doubled.
		$numCubes2 = $numCubes * 2; //This is the value that will be submitted into the "team_points" database.
		$total += $numCubes2;
		$scale = explode ("|", $_POST['scale']);
		$rscale = $scale[0];
		$pscale = $scale[1];
		$total += $pscale;
		$highScale = explode ("|", $_POST['highScale']);
		$rHS = $highScale[0];
		$pHS = $highScale[1];
		$total += $pHS;
		$switch = explode ("|", $_POST['switch']);
		$rswitch = $switch[0];
		$pswitch = $switch[1];
		$total += $pswitch;
		$specialty = ($_POST['specialty']); //This value is used in both databases.
		$climb = explode ("|", $_POST['climb']);
		$rclimb = $climb[0];
		$pclimb = $climb[1];
		$total += $pclimb;
		$multiClimb = explode ("|", $_POST['multiClimb']);
		$rMC = $multiClimb[0];
		$pMC = $multiClimb[1];
		$total += $pMC;
		$extra = ($_POST['extra']); //This value is used in the "robot_info" database.

		$auto = file("auto.txt");

		$pdeliverCube = (int) $auto[0];
		$total += $pdeliverCube;
		$phitScale = (int) $auto[1];
		$total += (int) $phitScale;
		$phitSwitch = $auto[2];
		$total += (int) $phitSwitch;
		$pcrossBaseline = $auto[3];
		$total += (int) $pcrossBaseline;

		//Create customer query
		$query ="INSERT INTO robot_info (teamNumber, size, speed, strength, strategy, numCubes, scale, highScale, switch, specialty, climb, multiClimb, extra)
								VALUES ('$teamNumber','$size','$rspeed','$rstrength','$strategy','$numCubes','$rscale','$rHS',
										'$rswitch','$specialty','$rclimb','$rMC','$extra')";
		$query2 ="INSERT INTO team_points (teamNumber, deliverCube, hitScale, hitSwitch, crossBaseline, size, speed, strength, strategy, numCubes, scale, highScale,
											switch, specialty, climb, multiClimb, total)
								VALUES ('$teamNumber','$pdeliverCube','$phitScale','$phitSwitch','$pcrossBaseline','$size','$pspeed','$pstrength','$strategy','$numCubes2',
										'$pscale','$pHS','$pswitch','$specialty','$pclimb','$pMC','$total')";
		$query3 ="UPDATE team_info
					SET teamPoints='$total'
					WHERE teamNumber='$teamNumber'
					";
		
		//Run query
		$mysqli->query($query);
		$mysqli->query($query2);
		$mysqli->query($query3);
		
		$msg='Robot Information Added';
		header('Location: teamList.php?'.urlencode($msg).'');
		exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>A-Team Robotics Scouting Page</title>
    <!-- Bootstrap core CSS -->
    <link href="css/main.css" rel="stylesheet">
    <!-- Custom styles for this template -->
		<link href="css/custom.css" rel="stylesheet">
		
	</head>
	
  <body>

    <div class="container">

      <div class="header">

        <ul class="nav nav-pills pull-right">
				  <li><a href="homePage.php">Home Page</a></li>
          <li ><a href="teamList.php">Team List</a></li>
          <li ><a href="addTeam.php">Add Team</a></li>
		  <li><a href="autonomous.php">Autonomous</a></li>
          <li class="active"><a href="robot.php">Robot Information</a></li>
		</ul>
				
        <h3 style="color:purple; font:bold;">A-Team Scouting Page</h3>
	  </div> 
			
      <div class="row marketing">

        <div class="col-lg-12">
				 <h2>Add Team</h2>
				 
		 <form role="form" method="post" action="robot.php">

		 	<div class="form-group">
    		<label class="form-group">Select</label> <!-- used to be Team Number -->
    		<label for="exampleFormControlSelect1">Team Number</label> <!-- used to be Example Select -->
    		<select class="form-control" id="exampleFormControlSelect1" name="selectTeam">
					<?php
		 			if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							echo "<option>" . $row["teamNumber"]. "<br>" . "</option>";
						}
					} else {
						echo "No results.";
					}
		 		?>
    		</select>
			</div>
			<!-- Get the size of the robot. -->
		 	<div class="form-check">
			  <label class="form-check-label">How big is the robot?</label>
				<div>
					 <b>Small </b><input type="radio" name="size" class="form-check-input" id="size" value="Small"><br />
					 <b>Medium </b><input type="radio" name="size" class="form-check-input" id="size" value="Medium"><br />
                     <b>Large </b><input type="radio" name="size" class="form-check-input" id="size" value="Large"><br /><br />
				</div>
			</div>
			<!-- Get the speed of the robot. -->
			 <div class="form-check">
			  <label class="form-check-label">How fast is it?</label>
				<div>
		 			<b>Really Slow </b><input type="radio" name="speed" class="form-check-input" id="speed" value="Really_Slow|0"><br />
					<b>Slow </b><input type="radio" name="speed" class="form-check-input" id="speed" value="Slow|1"><br />
                    <b>Fast </b><input type="radio" name="speed" class="form-check-input" id="speed" value="Fast|2"><br />
                    <b>Really Fast </b><input type="radio" name="speed" class="form-check-input" id="speed" value="Really_Fast|3"><br /><br />
				</div>
			 </div>
			 <!-- Get the strength of the robot. -->
			<div class="form-check">
				<label class="form-check-label">How strong is it?</label>
				<div>
		 			<b>Weak and Brittle </b><input type="radio" name="strength" class="form-check-input" id="strength" value="Weak/Brittle|0"><br />
					<b>Functional </b><input type="radio" name="strength" class="form-check-input" id="strength" value="Functional|1"><br />
                    <b>Tougher </b><input type="radio" name="strength" class="form-check-input" id="strength" value="Tougher|2"><br />
                    <b>Strong and Durable </b><input type="radio" name="strength" class="form-check-input" id="strength" value="Strong/Durable|3"><br /><br />
				</div>
			 </div>
			 <!-- Get the strategy of the team. -->
			<div class="form-check">
				<label class="form-check-label">What's its strategy?</label>
				<div>
		 			<b>Offensive </b><input type="radio" name="strategy" class="form-check-input" id="strategy" value="Offense"><br />
					<b>Defensive </b><input type="radio" name="strategy" class="form-check-input" id="strategy" value="Defense"><br />
                    <b>Both </b><input type="radio" name="strategy" class="form-check-input" id="strategy" value="Both_Offense_And_Defense"><br /><br />
				</div>
			 </div>
			<!-- Get the amount of cubes the robot has collected and exchanged. -->
             <div class="form-check">
				<label class="form-check-label">How many cubes did they get?</label>
				<input name="numCubes" type="text" class="form-control" placeholder="Number of Cubes"><br />
			 </div>
			<!-- Get a "boolean" value to determine if the robot hit the scale or not. -->
			 <div class="form-check">
				<label class="form-check-label">Did it hit the scale?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="scale" class="form-check-input" id="scale" value="Yes|3"><br />
					<b>No </b><input type="radio" name="scale" class="form-check-input" id="scale" value="No|0"><br /><br />
				</div>
			 </div>
			 <!-- Get a "boolean" value to determine if the robot hit the high 6 feet tall scale or not. -->
			 <div class="form-check">
				<label class="form-check-label">Can it hit the high scale (the full 6 feet)?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="highScale" class="form-check-input" id="highScale" value="Yes|4"><br />
					<b>No </b><input type="radio" name="highScale" class="form-check-input" id="highScale" value="No|0"><br /><br />
				</div>
			 </div>
			 <!-- Get a "boolean" value to determine if the robot hit the switch or not. -->
			 <div class="form-check">
				<label class="form-check-label">Did it hit the switch?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="switch" class="form-check-input" id="switch" value="Yes|2"><br />
					<b>No </b><input type="radio" name="switch" class="form-check-input" id="switch" value="No|0"><br /><br />
				</div>
			 </div>
			 <!-- Get the special feature of the robot. -->
             <div class="form-check">
				<label class="form-check-label">What's its specialty? (what is it best at)</label>
				<div>
		 			<b>Collecting Cubes </b><input type="radio" name="specialty" class="form-check-input" id="specialty" value="Collecting_Cubes"><br />
					<b>Defense </b><input type="radio" name="specialty" class="form-check-input" id="specialty" value="Defense"><br />
                    <b>Climbing </b><input type="radio" name="specialty" class="form-check-input" id="specialty" value="Climbing"><br />
                    <b>Autonomous </b><input type="radio" name="specialty" class="form-check-input" id="specialty" value="Autonomous"><br /><br />
				</div>
			 </div>
			 <!-- Get a "boolean" value to determine if the robot can climb or not. -->
             <div class="form-check">
				<label class="form-check-label">Can it climb?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="climb" class="form-check-input" id="climb" value="Yes|4"><br />
					<b>No </b><input type="radio" name="climb" class="form-check-input" id="climb" value="No|0"><br /><br />
				</div>
			 </div>
			 <!-- Get a "boolean" value to determine if the robot can climb with other robots at the same time or not. -->
			 <div class="form-check">
				<label class="form-check-label">Can it climb with the other robots (team climbing)?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="multiClimb" class="form-check-input" id="multiClimb" value="Yes|6"><br />
					<b>No </b><input type="radio" name="multiClimb" class="form-check-input" id="multiClimb" value="No|0"><br /><br />
				</div>
			 </div>
			 <!-- Get any other information the user thought was important about the robot. -->
             <div class="form-check">
				<label class="form-check-label">Anything else to say about the robot?</label>
				<input name="extra" type="text" class="form-control" placeholder="Whatever Else Is Important"><br />
			 </div>
		<!-- Submit the information about the robot. -->
		 <br><input type="submit" class="btn btn-default" value="Add Robot Info" /></br>
		</form>
        </div>
			</div>
			
      <div class="footer">
			<p style="color:purple;">&copy; A-Team Robotics 2018</p>
      </div>
    </div> <!-- /container -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  </body>
</html>