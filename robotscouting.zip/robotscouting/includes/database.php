<?php
//Connect to Database
$db_host = 'localhost';
$db_name = 'robotics_scouting';
$db_user = 'ateam1';
$db_pass = 'h0YxSlN3hvRchknu';

//Create mysqli Object
$mysqli = new mysqli($db_host,$db_user,$db_pass,$db_name);

//Error Handler
if(mysqli_connect_errno()){
	echo 'This Connection Failed'. mysqli1_connect_error();
	die();
}