<?php include('includes/database.php'); ?>
<?php
	//Create the select query
	$query ="SELECT DISTINCT
	     teamNumber
			 FROM team_info
			 ORDER BY id DESC
			 ";
			
	//Get results
	$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
?>
<?php
	if($_POST){
		//Get variables from post array
		$teamNumber = ($_POST['selectTeam']);
		$deliverCube = explode ("|", $_POST['deliverCube']);
		$rdeliverCube = $deliverCube[0];
		$pdeliverCube = $deliverCube[1];
		$hitScale = explode ("|", $_POST['hitScale']);
		$rhitScale = $hitScale[0];
		$phitScale = $hitScale[1];
		$hitSwitch = explode ("|", $_POST['hitSwitch']);
		$rhitSwitch = $hitSwitch[0];
		$phitSwitch = $hitSwitch[1];
		$crossBaseline = explode ("|", $_POST['crossBaseline']);
		$rcrossBaseline = $crossBaseline[0];
		$pcrossBaseline = $crossBaseline[1];

		$auto = fopen ("auto.txt", "w");
		fwrite ($auto, $pdeliverCube);
		fwrite ($auto, "\n");
		fwrite ($auto, $phitScale);
		fwrite ($auto, "\n");
		fwrite ($auto, $phitSwitch);
		fwrite ($auto, "\n");
		fwrite ($auto, $pcrossBaseline);
		fclose ($auto);
		
		//Create customer query
		$query ="INSERT INTO auto_info (teamNumber, deliverCube, hitScale, hitSwitch, crossBaseline)
								VALUES ('$teamNumber','$rdeliverCube','$rhitScale','$rhitSwitch','$rcrossBaseline')";
		//Run query
		$mysqli->query($query);
		$msg='Autonomous Added';
		header('Location: robot.php?'.urlencode($msg).'');
		exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>A-Team Robotics Scouting Page</title>
    <!-- Bootstrap core CSS -->
    <link href="css/main.css" rel="stylesheet">
    <!-- Custom styles for this template -->
		<link href="css/custom.css" rel="stylesheet">
		
	</head>
	
  <body>

    <div class="container">

      <div class="header">

        <ul class="nav nav-pills pull-right">
				  <li><a href="homePage.php">Home Page</a></li>
          <li ><a href="teamList.php">Team List</a></li>
          <li ><a href="addTeam.php">Add Team</a></li>
					<li class="active"><a href="teamList.php">Autonomous</a></li>
					<li ><a href="robot.php">Robot Information</a></li>
				</ul>
				
        <h3 style="color:purple; font:bold;">A-Team Scouting Page</h3>
			</div> 
			
      <div class="row marketing">

        <div class="col-lg-12">
				 <h2>Add Team</h2>
				 
		 <form role="form" method="post" action="autonomous.php">

		 	<div class="form-group">
    		<label class="form-group">Select</label>
    		<label for="exampleFormControlSelect1">Team Number</label>
    		<select class="form-control" id="exampleFormControlSelect1" name="selectTeam">
					<?php
		 			if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							echo "<option>" . $row["teamNumber"]. "<br>" . "</option>";
						}
					} else {
						echo "No results.";
					}
		 		?>
    		</select>
			</div>
		 	<div class="form-check">
			  <label class="form-check-label">Delivered a Cube?</label>
				<div>
					 <b>Yes </b><input type="radio" name="deliverCube" class="form-check-input" id="deliverCube" value="Yes|3"><br />
					<b>No </b><input type="radio" name="deliverCube" class="form-check-input" id="deliverCube" value="No|0"><br />
				</div>
			</div>

			 <div class="form-check">
			  <label class="form-check-label">Hit the Switch?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="hitSwitch" class="form-check-input" id="hitSwitch" value="Yes|3"><br />
					<b>No </b><input type="radio" name="hitSwitch" class="form-check-input" id="hitSwitch" value="No|0"><br />
				</div>
			 </div>
			 
			<div class="form-check">
				<label class="form-check-label">Hit the Scale?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="hitScale" class="form-check-input" id="hitScale" value="Yes|5"><br />
					<b>No </b><input type="radio" name="hitScale" class="form-check-input" id="hitScale" value="No|0"><br />
				</div>
			 </div>
			 
			<div class="form-check">
				<label class="form-check-label">Crossed the Baseline?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="crossBaseline" class="form-check-input" id="crossBaseline" value="Yes|1"><br />
					<b>No </b><input type="radio" name="crossBaseline" class="form-check-input" id="crossBaseline" value="No|0"><br />
				</div>
			 </div>
			 
		 <br><input type="submit" class="btn btn-default" value="Add Auto Info" /></br>
		</form>
        </div>
			</div>
			
      <div class="footer">
			<p style="color:purple;">&copy; A-Team Robotics 2018</p>
      </div>
    </div> <!-- /container -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  </body>
</html>