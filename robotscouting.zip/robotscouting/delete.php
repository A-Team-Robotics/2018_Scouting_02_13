<?php include('includes/database.php'); ?>
<?php
	if(isset($_GET['Team']) && $_GET){
	$teamNumber = $_GET['Team'];
		
		//Create customer query
		$query ="DELETE FROM team_info WHERE teamNumber='$teamNumber'";
		$query2 ="DELETE FROM auto_info WHERE teamNumber='$teamNumber'";
		$query3 ="DELETE FROM robot_info WHERE teamNumber='$teamNumber'";
		$query4 ="DELETE FROM team_points WHERE teamNumber='$teamNumber'";
		//Run query
		$mysqli->query($query);
		$mysqli->query($query2);
		$mysqli->query($query3);
		$mysqli->query($query4);
	}
?>
<?php 

$query = "SELECT MAX(id) FROM team_info; ALTER TABLE team_info AUTO_INCREMENT = 7";
$query2 = "SELECT MAX(id) FROM auto_info; ALTER TABLE auto_info AUTO_INCREMENT = 7";
$query3 = "SELECT MAX(id) FROM robot_info; ALTER TABLE robot_info AUTO_INCREMENT = 7";
$query4 = "SELECT MAX(id) FROM team_points; ALTER TABLE team_points AUTO_INCREMENT = 7";
$mysqli->query($query);
$mysqli->query($query2);
$mysqli->query($query3);
$mysqli->query($query4);
$msg='Team with number '.$teamNumber.'has been deleted';
header('Location: teamList.php?'.urlencode($msg).'');
exit;
?>