<?php include('includes/database.php'); ?>
<?php
  $ID = 0;
  $teamNum = 0;

  if(isset($_GET['id']) && isset($_GET['team'])){
      $ID=$_GET['id'];
      $teamNum = $_GET['team'];
  }
?>
<?php
	//Create customer select query
	$query ="SELECT * FROM team_info
			 WHERE team_info.teamNumber = $teamNum";
	$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
	
	$query2 ="SELECT * FROM auto_info
			WHERE auto_info.teamNumber = $teamNum";
	$result2 = $mysqli->query($query2) or die($mysqli->error.__LINE__);

	$query3 ="SELECT * FROM robot_info
			WHERE robot_info.teamNumber = $teamNum";
	$result3 = $mysqli->query($query3) or die($mysqli->error.__LINE__);

	$query4 ="SELECT * FROM team_points
			WHERE team_points.teamNumber = $teamNum";
	$result4 = $mysqli->query($query4) or die($mysqli->error.__LINE__);
		
	if($result = $mysqli->query($query)){
		//Fetch object array
		while($row = $result->fetch_assoc()) {
			$teamName = $row['teamName'];
			$teamNumber = $row['teamNumber'];
			$teamSchoolName = $row['teamSchoolName'];
			$teamEmail = $row['teamEmail'];
			$teamAge = $row['teamAge'];
			$teamLocation = $row['teamLocation'];
		}
		//Free Result set
		$result->close();
	}

	if($result2 = $mysqli->query($query2)){
		//Fetch object array
		while($row2 = $result2->fetch_assoc()) {
			$deliverCube = $row2['deliverCube'];
			$hitSwitch = $row2['hitSwitch'];
			$hitScale = $row2['hitScale'];
			$crossBaseline = $row2['crossBaseline'];
		}
		//Free Result set
		$result2->close();
	}

	if($result3 = $mysqli->query($query3)){
		//Fetch object array
		while($row3 = $result3->fetch_assoc()) {
			$size = $row3['size'];
			$speed = $row3['speed'];
			$strength = $row3['strength'];
			$strategy = $row3['strategy'];
			$numCubes = $row3['numCubes'];
			$scale = $row3['scale'];
			$highScale = $row3['highScale'];
			$switch = $row3['switch'];
			$specialty = $row3['specialty'];
			$climb = $row3['climb'];
			$multiClimb = $row3['multiClimb'];
			$extra = $row3['extra'];
		}
		//Free Result set
		$result3->close();
	}
	
	if($result4 = $mysqli->query($query4)) {
		//Fetch object array
		while($row4 = $result4->fetch_assoc()) {
			$pdeliverCube = $row4['deliverCube'];
			$phitSwitch = $row4['hitSwitch'];
			$phitScale = $row4['hitScale'];
			$pcrossBaseline = $row4['crossBaseline'];
			$pspeed = $row4['speed'];
			$pstrength = $row4['strength'];
			$pnumCubes = $row4['numCubes'];
			$pscale = $row4['scale'];
			$phighScale = $row4['highScale'];
			$pswitch = $row4['switch'];
			$pclimb = $row4['climb'];
			$pmultiClimb = $row4['multiClimb'];
			$total = $row4['total'];
		}
		//Free Result set
		$result4->close();
	}
?>
<?php
	if($_POST){
		//Assign GET Variable
		$id = $_GET['id'];
	
		//Assign Team Variables
		$teamName = ($_POST['teamName']);
		$teamNumber = ($_POST['teamNumber']);
		$teamSchoolName = ($_POST['teamSchoolName']);
		$teamEmail = ($_POST['teamEmail']);
		$teamAge = ($_POST['teamAge']);
		$teamLocation = ($_POST['teamLocation']);

		//Assign Auto Variables
		$deliverCube = explode ("|", $_POST['deliverCube']);
		$hitSwitch = explode ("|", $_POST['hitSwitch']);
		$hitScale = explode ("|", $_POST['hitScale']);
		$crossBaseline = explode ("|", $_POST['crossBaseline']);

		//Assign Robot Variables
		$size = ($_POST['size']);
		$speed = explode ("|", $_POST['speed']);
		$strength = explode ("|", $_POST['strength']);
		$strategy = ($_POST['strategy']);
		$numCubes = ($_POST['numCubes']);
		$scale = explode ("|", $_POST['scale']);
		$highScale = explode ("|", $_POST['highScale']);
		$switch = explode ("|", $_POST['switch']);
		$specialty = ($_POST['specialty']);
		$climb = explode ("|", $_POST['climb']);
		$multiClimb = explode ("|", $_POST['multiClimb']);
		$extra = ($_POST['extra']);

		//Assign Submitting Auto Variables
		$rdeliverCube = $deliverCube[0];
		$rhitSwitch = $hitSwitch[0];
		$rhitScale = $hitScale[0];
		$rcrossBaseline = $crossBaseline[0];

		//Assign Submitting Robot Variables
		$rspeed = $speed[0];
		$rstrength = $strength[0];
		$rscale = $scale[0];
		$rhighScale = $highScale[0];
		$rswitch = $switch[0];
		$rclimb = $climb[0];
		$rmultiClimb = $multiClimb[0];

		//Assign Points Variables (Auto)
		$pdeliverCube = $deliverCube[1];
		$phitSwitch = $hitSwitch[1];
		$phitScale = $hitScale[1];
		$pcrossBaseline = $crossBaseline[1];

		//Assign Points Variables (Robot)
		$pspeed = $speed[1];
		$pstrength = $strength[1];
		$pnumCubes = $numCubes * 2;
		$pscale = $scale[1];
		$phighScale = $highScale[1];
		$pswitch = $switch[1];
		$pclimb = $climb[1];
		$pmultiClimb = $multiClimb[1];

		//Create customer update
		$query = "UPDATE team_info
				  SET
				  teamName='$teamName',
				  teamNumber='$teamNumber',
					teamSchoolName='$teamSchoolName',
				  teamEmail='$teamEmail',
					teamLocation='$teamLocation',
				  teamAge='$teamAge'
				  WHERE id=$id
					";
		$query2 = "UPDATE auto_info
					SET
					teamNumber='$teamNumber',
					deliverCube='$rdeliverCube',
					hitScale='$rhitScale',
					hitSwitch='$rhitSwitch',
					crossBaseline='$rcrossBaseline'
					WHERE teamNumber=$teamNum
					";
		$query3 = "UPDATE robot_info
					SET
					teamNumber='$teamNumber',
					size='$size',
					speed='$rspeed',
					strength='$rstrength',
					strategy='$strategy',
					numCubes='$numCubes',
					scale='$rscale',
					highScale='$rhighScale',
					switch='$rswitch',
					specialty='$specialty',
					climb='$rclimb',
					multiClimb='$rmultiClimb',
					extra='$extra'
					WHERE teamNumber=$teamNum
					";
		$query4 = "UPDATE team_points
					SET
					teamNumber='$teamNumber',
					deliverCube='$pdeliverCube',
					hitScale='$phitScale',
					hitSwitch='$phitSwitch',
					crossBaseline='$pcrossBaseline'
					size='$size',
					speed='$pspeed',
					strength='$pstrength',
					strategy='$strategy',
					numCubes='$pnumCubes',
					scale='$pscale',
					highScale='$phighScale',
					switch='$pswitch',
					specialty='$specialty',
					climb='$pclimb',
					multiClimb='$pmultiClimb'
					WHERE teamNumber=$teamNum
					";
		
		$mysqli->query($query);
		$mysqli->query($query2);
		$mysqli->query($query3);
		$mysqli->query($query4);
		$msg="Team Updated";
		header('Location: teamList.php?'.urlencode($msg).'');
		exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>A-Team Robotics Scouting Page</title>
    <!-- Bootstrap core CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <link href="css/main.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/custom.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <div class="header">
        <ul class="nav nav-pills pull-right">
          <li ><a href="homepage.php">Team List</a></li>
          <li class="active"><a href="editTeam.php">editTeam</a></li>
        </ul>
        <h3 style="color:purple; font:bold;">A-Team Scouting Page</h3>
      </div>

      <div class="row marketing">
			<div class="col-lg-12">
			 <h2>Edit Team</h2>
			 
	 <form role="form" method="post" action="editTeam.php?id=<?php echo $id; ?>">

		<div class="form-group" id="etn">
			<label style="font-size:15px">Team Name</label>
			<input name="teamName" type="text" class="form-control" value="<?php echo $teamName; ?>"placeholder="Enter Team Name"><br />
		</div>

		<div class="form-group" id="etn2">
			<label style="font-size:15px">Team Number</label>
			<input name="teamNumber" type="text" class="form-control" value="<?php echo $teamNumber; ?>"placeholder="Enter Last Name"><br />
		</div>

		<div class="form-group" id="etsn">
			<label style="font-size:15px">Team School Name</label>
			<input name="teamSchoolName" type="text" class="form-control" value="<?php echo $teamSchoolName ?>"placeholder="Enter School Name"><br />
		</div>

		<div class="form-group" id="ete">
			<label style="font-size:15px">Team Email</label>
			<input name="teamEmail" type="email" class="form-control" value="<?php echo $teamEmail ?>"placeholder="Enter Email"><br />
		</div>

		<div class="form-group" id="eta">
			<label style="font-size:15px">Team Age</label>
			<input name="teamAge" type="text" class="form-control" value="<?php echo $teamAge ?>"placeholder="Enter Age"><br />
		</div>

		<div class="form-group" id="etl"> 
			<label style="font-size:15px">Team Location</label> 
			<input name="teamLocation" type="text" class="form-control" value="<?php echo $teamLocation ?>"placeholder="Enter Team Location"><br />
		</div>

		<div class="form-check" id="edc">
		<label class="form-check-label" style="font-size:15px">Delivered a Cube?</label>
				<div>
					 <b>Yes </b><input type="radio" name="deliverCube" class="form-check-input" id="deliverCube" value="Yes|3"
							<?php if(isset ($deliverCube) && $deliverCube == "Yes") echo " checked";?>><br />
					<b>No </b><input type="radio" name="deliverCube" class="form-check-input" id="deliverCube" value="No|0"
							<?php if(isset ($deliverCube) && $deliverCube == "No") echo " checked";?>><br />
				</div>
			</div>

			 <div class="form-check" id="ehs">
			  <label class="form-check-label" style="font-size:15px">Hit the Switch?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="hitSwitch" class="form-check-input" id="hitSwitch" value="Yes|3"
					 		<?php if(isset ($hitSwitch) && $hitSwitch == "Yes") echo " checked";?>><br />
					<b>No </b><input type="radio" name="hitSwitch" class="form-check-input" id="hitSwitch" value="No|0"
							<?php if(isset ($hitSwitch) && $hitSwitch == "No") echo " checked";?>><br />
				</div>
			 </div>
			 
			<div class="form-check" id="ehs2">
				<label class="form-check-label" style="font-size:15px">Hit the Scale?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="hitScale" class="form-check-input" id="hitScale" value="Yes|5"
					 		<?php if(isset ($hitScale) && $hitScale == "Yes") echo " checked";?>><br />
					<b>No </b><input type="radio" name="hitScale" class="form-check-input" id="hitScale" value="No|0"
							<?php if(isset ($hitScale) && $hitScale == "No") echo " checked";?>><br />
				</div>
			 </div>
			 
			<div class="form-check" id="ecb">
				<label class="form-check-label" style="font-size:15px">Crossed the Baseline?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="crossBaseline" class="form-check-input" id="crossBaseline" value="Yes|1"
					 		<?php if(isset ($crossBaseline) && $crossBaseline == "Yes") echo " checked";?>><br />
					<b>No </b><input type="radio" name="crossBaseline" class="form-check-input" id="crossBaseline" value="No|0"
							<?php if(isset ($crossBaseline) && $crossBaseline == "No") echo " checked";?>><br />
				</div>
			 </div>

			 <div class="form-check" id="ers">
			  <label class="form-check-label" style="font-size:15px">How big is the robot?</label>
				<div>
					 <b>Small </b><input type="radio" name="size" class="form-check-input" id="size" value="Small"
					 		<?php if(isset ($size) && $size == "Small") echo " checked";?>><br />
					 <b>Medium </b><input type="radio" name="size" class="form-check-input" id="size" value="Medium"
					 		<?php if(isset ($size) && $size == "Medium") echo " checked";?>><br />
           <b>Large </b><input type="radio" name="size" class="form-check-input" id="size" value="Large"
					 		<?php if(isset ($size) && $size == "Large") echo " checked";?>><br /><br />
				</div>
			</div>
			
			 <div class="form-check" id="ers2">
			  <label class="form-check-label" style="font-size:15px">How fast is it?</label>
				<div>
		 			<b>Really Slow </b><input type="radio" name="speed" class="form-check-input" id="speed" value="Really_Slow|0"
					 		<?php if(isset ($speed) && $speed == "Really_Slow") echo " checked";?>><br />
					<b>Slow </b><input type="radio" name="speed" class="form-check-input" id="speed" value="Slow|1"
							<?php if(isset ($speed) && $speed == "Slow") echo " checked";?>><br />
          <b>Fast </b><input type="radio" name="speed" class="form-check-input" id="speed" value="Fast|2"
							<?php if(isset ($speed) && $speed == "Fast") echo " checked";?>><br />
          <b>Really Fast </b><input type="radio" name="speed" class="form-check-input" id="speed" value="Really_Fast|3"
							<?php if(isset ($speed) && $speed == "Really_Fast") echo " checked";?>><br /><br />
				</div>
			 </div>
			 
			<div class="form-check" id="ers3">
				<label class="form-check-label" style="font-size:15px">How strong is it?</label>
				<div>
		 			<b>Weak and Brittle </b><input type="radio" name="strength" class="form-check-input" id="strength" value="Weak/Brittle|0"
							<?php if(isset ($strength) && $strength == "Weak/Brittle") echo " checked";?>><br />
					<b>Functional </b><input type="radio" name="strength" class="form-check-input" id="strength" value="Functional|1"
							<?php if(isset ($strength) && $strength == "Functional") echo " checked";?>><br />
          <b>Tougher </b><input type="radio" name="strength" class="form-check-input" id="strength" value="Tougher|2"
							<?php if(isset ($strength) && $strength == "Tougher") echo " checked";?>><br />
          <b>Strong and Durable </b><input type="radio" name="strength" class="form-check-input" id="strength" value="Strong/Durable|3"
							<?php if(isset ($strength) && $strength == "Strong/Durable") echo " checked";?>><br /><br />
				</div>
			 </div>
			 
			<div class="form-check" id="ers4">
				<label class="form-check-label" style="font-size:15px">What's its strategy?</label>
				<div>
		 			<b>Offensive </b><input type="radio" name="strategy" class="form-check-input" id="strategy" value="Offense"
					 		<?php if(isset ($strategy) && $strategy == "Offense") echo " checked";?>><br />
					<b>Defensive </b><input type="radio" name="strategy" class="form-check-input" id="strategy" value="Defense"
							<?php if(isset ($strategy) && $strategy == "Defense") echo " checked";?>><br />
          <b>Both </b><input type="radio" name="strategy" class="form-check-input" id="strategy" value="Both_Offense_And_Defense"
							<?php if(isset ($strategy) && $strategy == "Both_Offense_And_Defense") echo " checked";?>><br /><br />
				</div>
			 </div>
			
			 <div class="form-group" id="enc"> 
			 <label class="form-check-label" style="font-size:15px">How many cubes did they get?</label> 
			 <input name="teamLocation" type="text" class="form-control" value="<?php echo $numCubes ?>"placeholder="Number of Cubes">
		 </div>
			
			 <div class="form-check" id="erhs">
				<label class="form-check-label" style="font-size:15px">Did it hit the scale?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="scale" class="form-check-input" id="scale" value="Yes|3"
					 		<?php if(isset ($scale) && $scale == "Yes") echo " checked";?>><br />
					<b>No </b><input type="radio" name="scale" class="form-check-input" id="scale" value="No|0"
							<?php if(isset ($scale) && $scale == "No") echo " checked";?>><br /><br />
				</div>
			 </div>
			 
			 <div class="form-check" id="erhhs">
				<label class="form-check-label" style="font-size:15px">Can it hit the high scale (the full 6 feet)?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="highScale" class="form-check-input" id="highScale" value="Yes|4"
					 		<?php if(isset ($highScale) && $highScale == "Yes") echo " checked";?>><br />
					<b>No </b><input type="radio" name="highScale" class="form-check-input" id="highScale" value="No|0"
							<?php if(isset ($highScale) && $highScale == "No") echo " checked";?>><br /><br />
				</div>
			 </div>
			 
			 <div class="form-check" id="erhs2">
				<label class="form-check-label" style="font-size:15px">Did it hit the switch?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="switch" class="form-check-input" id="switch" value="Yes|2"
					 		<?php if(isset ($switch) && $switch == "Yes") echo " checked";?>><br />
					<b>No </b><input type="radio" name="switch" class="form-check-input" id="switch" value="No|0"
							<?php if(isset ($switch) && $switch == "No") echo " checked";?>><br /><br />
				</div>
			 </div>

      <div class="form-check" id="ers5">
				<label class="form-check-label" style="font-size:15px">What's its specialty? (what is it best at)</label>
				<div>
		 			<b>Collecting Cubes </b><input type="radio" name="specialty" class="form-check-input" id="specialty" value="Collecting_Cubes"
					 		<?php if(isset ($specialty) && $specialty == "Collecting_Cubes") echo " checked";?>><br />
					<b>Defense </b><input type="radio" name="specialty" class="form-check-input" id="specialty" value="Defense"
							<?php if(isset ($specialty) && $specialty == "Defense") echo " checked";?>><br />
          <b>Climbing </b><input type="radio" name="specialty" class="form-check-input" id="specialty" value="Climbing"
							<?php if(isset ($specialty) && $specialty == "Climbing") echo " checked";?>><br />
          <b>Autonomous </b><input type="radio" name="specialty" class="form-check-input" id="specialty" value="Autonomous"
							<?php if(isset ($specialty) && $specialty == "Autonomous") echo " checked";?>><br /><br />
				</div>
			 </div>
			 
      <div class="form-check" id="ercc">
				<label class="form-check-label" style="font-size:15px">Can it climb?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="climb" class="form-check-input" id="climb" value="Yes|4"
					 		<?php if(isset ($climb) && $climb == "Yes") echo " checked";?>><br />
					<b>No </b><input type="radio" name="climb" class="form-check-input" id="climb" value="No|0"
							<?php if(isset ($climb) && $climb == "No") echo " checked";?>><br /><br />
				</div>
			 </div>
			 
			 <div class="form-check" id="ermc">
				<label class="form-check-label" style="font-size:15px">Can it climb with the other robots (team climbing)?</label>
				<div>
		 			<b>Yes </b><input type="radio" name="multiClimb" class="form-check-input" id="multiClimb" value="Yes|6"
					 		<?php if(isset ($multiClimb) && $multiClimb == "Yes") echo " checked";?>><br />
					<b>No </b><input type="radio" name="multiClimb" class="form-check-input" id="multiClimb" value="No|0"
							<?php if(isset ($multiClimb) && $multiClimb == "No") echo " checked";?>><br /><br />
				</div>
			 </div>

      <div class="form-check" id="ere">
				<label class="form-check-label" style="font-size:15px">Anything else to say about the robot?</label>
				<input name="extra" type="text" class="form-control" value="<?php echo $extra ?>" placeholder="Whatever Else Is Important"><br />
			 </div>

		<br><input type="submit" class="btn btn-default" value="Submit Changes" id="es" /></br>
	</form>
			</div>
			<div>
				<form role="form" method="get" action="delete.php?id=<?php echo $id; ?>">
     			<p><input type="checkbox" name="Team" value="<?php echo $teamNumber ?>">Delete: <?php echo $teamName ?></p>
     			<input type="submit" value="Delete">
		 	</div>
		</div>
      <div class="footer">
			<p style="color:purple;">&copy; A-Team Robotics 2018</p>
      </div>

    </div> <!-- /container -->
  

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  </body>
</html>